import os
from pathlib import Path
import docx
import PyPDF2
import moviepy.editor as mp
import pytesseract
from PIL import Image

# Função para processar arquivos de texto .docx
def process_docx(file_path):
    doc = docx.Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

# Função para processar arquivos PDF
def process_pdf(file_path):
    try:
        with open(file_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            text = ""
            for page in reader.pages:
                text += page.extract_text() or ""
        return text
    except Exception as e:
        return f"Erro ao processar PDF {file_path}: {e}"

# Função para processar arquivos de imagem com OCR
def process_image(file_path):
    try:
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        return f"Erro ao processar imagem {file_path}: {e}"

# Função para processar arquivos de áudio (transcrição para texto usando Whisper)
def process_audio(file_path):
    try:
        import whisper
        model = whisper.load_model("base")
        result = model.transcribe(file_path)
        return result["text"]
    except ImportError:
        return "Whisper não está instalado. Instale usando 'pip install whisper'."
    except Exception as e:
        return f"Erro ao processar áudio {file_path}: {e}"

# Função para processar arquivos de vídeo (extração de áudio e transcrição)
def process_video(file_path):
    try:
        video = mp.VideoFileClip(file_path)
        audio_path = file_path.with_suffix('.mp3')  # Substituir extensão por .mp3
        video.audio.write_audiofile(audio_path, logger=None)  # Suprime logs desnecessários
        return process_audio(audio_path)  # Processar o áudio extraído
    except Exception as e:
        return f"Erro ao processar vídeo {file_path}: {e}"

# Função para processar arquivos de código
def process_code(file_path):
    try:
        with open(file_path, 'r') as f:
            code = f.read()
        return code
    except Exception as e:
        return f"Erro ao processar código {file_path}: {e}"

# Função principal para processar todos os tipos de arquivos
def process_files():
    # Diretórios na raiz do projeto
    project_root = Path(__file__).resolve().parent.parent  # Subir uma pasta
    input_dir = project_root / "data"
    processed_dir = project_root / "processed"
    processed_dir.mkdir(parents=True, exist_ok=True)  # Criar se não existir
    
    # Verificar se o diretório de entrada existe
    if not input_dir.exists():
        print(f"O diretório '{input_dir}' não existe. Crie-o e adicione arquivos para processar.")
        return

    for folder in input_dir.iterdir():
        if folder.is_dir():
            for file in folder.iterdir():
                print(f"Processando: {file}")
                text = ""
                
                if file.suffix == '.docx':
                    text = process_docx(file)
                elif file.suffix == '.pdf':
                    text = process_pdf(file)
                elif file.suffix in ['.png', '.jpg', '.jpeg']:
                    text = process_image(file)
                elif file.suffix in ['.mp3', '.wav']:
                    text = process_audio(file)
                elif file.suffix == '.mp4':
                    text = process_video(file)
                elif file.suffix in ['.py', '.js', '.java', '.c', '.cpp']:
                    text = process_code(file)
                else:
                    print(f"Tipo de arquivo não suportado: {file.suffix}")
                    continue

                # Salvar os arquivos processados no diretório 'processed'
                output_file = processed_dir / f"{file.stem}_processed.txt"
                try:
                    with open(output_file, 'w', encoding='utf-8') as f:
                        f.write(text)
                    print(f"Arquivo processado salvo em: {output_file}")
                except Exception as e:
                    print(f"Erro ao salvar o arquivo {output_file}: {e}")

if __name__ == "__main__":
    process_files()
