import os
import docx
import PyPDF2
import moviepy.editor as mp
from pathlib import Path
import shutil

# Função para processar arquivos de texto .docx
def process_docx(file_path):
    doc = docx.Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

# Função para processar arquivos PDF
def process_pdf(file_path):
    with open(file_path, 'rb') as f:
        reader = PyPDF2.PdfReader(f)
        text = ""
        for page in range(len(reader.pages)):
            text += reader.pages[page].extract_text()
    return text

# Função para processar arquivos de áudio (transcrição para texto usando Whisper)
def process_audio(file_path):
    # Aqui é necessário integrar o Whisper ou similar para transcrever áudio
    import whisper
    model = whisper.load_model("base")
    result = model.transcribe(file_path)
    return result["text"]

# Função para processar arquivos de vídeo (extração de áudio)
def process_video(file_path):
    # Usar moviepy para extrair o áudio
    video = mp.VideoFileClip(file_path)
    audio_path = file_path.replace('.mp4', '.mp3')
    video.audio.write_audiofile(audio_path)
    return process_audio(audio_path)  # Processar o áudio extraído

# Função para processar arquivos de imagem (OCR com Tesseract)
def process_image(file_path):
    import pytesseract
    from PIL import Image
    image = Image.open(file_path)
    return pytesseract.image_to_string(image)

# Função para processar arquivos de código
def process_code(file_path):
    with open(file_path, 'r') as f:
        code = f.read()
    return code

# Função para garantir que a estrutura de pastas seja criada
def create_dir_structure(file_path, base_dir):
    relative_path = file_path.relative_to(base_dir)
    new_dir = base_dir / relative_path.parent
    new_dir.mkdir(parents=True, exist_ok=True)
    return new_dir / file_path.name

# Função principal para processar todos os tipos de arquivos
def process_files():
    input_dir = Path("input_dir")
    processed_dir = Path("processed")
    output_dir = Path("output_dir")
    
    # Criar diretórios de saída se não existirem
    processed_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for folder in input_dir.iterdir():
        if folder.is_dir():
            for file in folder.iterdir():
                if file.suffix == '.docx':
                    text = process_docx(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))
                elif file.suffix == '.pdf':
                    text = process_pdf(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))
                elif file.suffix in ['.mp3', '.wav']:
                    text = process_audio(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))
                elif file.suffix == '.mp4':
                    text = process_video(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))
                elif file.suffix in ['.py', '.js', '.java']:
                    text = process_code(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))
                elif file.suffix in ['.jpg', '.jpeg', '.png']:
                    text = process_image(file)
                    processed_path = create_dir_structure(file, input_dir)
                    with open(processed_path, 'w') as f:
                        f.write(text)
                    # Mover o arquivo original para output_dir
                    shutil.copy(file, create_dir_structure(file, output_dir))

if __name__ == "__main__":
    process_files()
