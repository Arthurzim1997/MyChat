import json
import os
import shutil
import logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pytesseract
from PIL import Image
import whisper
import moviepy.editor as mp
import docx
import PyPDF2
from colorama import Fore, Style, init

# Inicializar colorama e logging
init(autoreset=True)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Caminho para a pasta do script (mesma pasta onde o script está localizado)
base_dir = Path(__file__).parent

# Diretórios relativos à pasta do script
input_dir = base_dir / "input_dir"
output_dir = base_dir / "output_dir"
processed_dir = base_dir / "processed_dir"

# Subpastas que devem existir dentro de 'input_dir'
subfolders = ['audio', 'code', 'images', 'text', 'video']

# Garantir que as pastas principais e as subpastas existam
for directory in [input_dir, output_dir, processed_dir]:
    if not directory.exists():
        logging.info(f"{Fore.GREEN}Diretório {directory} não encontrado. Criando...")
        directory.mkdir(parents=True, exist_ok=True)

# Garantir que as subpastas dentro de 'input_dir', 'output_dir' e 'processed_dir' existam
for subfolder in subfolders:
    for base_path in [input_dir, output_dir, processed_dir]:
        subfolder_path = base_path / subfolder
        if not subfolder_path.exists():
            logging.info(f"{Fore.GREEN}Subpasta {subfolder_path} não encontrada. Criando...")
            subfolder_path.mkdir(parents=True, exist_ok=True)

# Função para garantir que a estrutura de pastas seja criada
def create_dir_structure(file_path, base_dir):
    new_dir = base_dir / file_path.relative_to(input_dir).parent
    new_dir.mkdir(parents=True, exist_ok=True)
    return new_dir / file_path.name

# Função para processar arquivos de imagem (OCR com Tesseract)
def process_image(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando {file_path} com OCR (Tesseract)...")
        image = Image.open(file_path)
        custom_config = r'--oem 3 --psm 3 --dpi 300'
        text = pytesseract.image_to_string(image, lang='por', config=custom_config)

        if text:
            json_data = {
                "file_name": file_path.name,
                "file_type": "image",
                "content": text
            }

            json_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.json')
            json_output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(json_output_path, 'w', encoding='utf-8') as json_file:
                json.dump(json_data, json_file, ensure_ascii=False, indent=4)

            logging.info(f"{Fore.GREEN}Texto extraído e salvo em {json_output_path}")
            return json_output_path
        else:
            logging.warning(f"{Fore.YELLOW}Nenhum texto extraído da imagem {file_path}.")
            return None
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos de áudio (usando Whisper)
model = whisper.load_model("base")
def process_audio(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando áudio {file_path} com Whisper...")
        result = model.transcribe(str(file_path))

        if result["text"]:
            json_data = {
                "file_name": file_path.name,
                "file_type": "audio",
                "content": result["text"]
            }

            json_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.json')
            json_output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(json_output_path, 'w', encoding='utf-8') as json_file:
                json.dump(json_data, json_file, ensure_ascii=False, indent=4)

            logging.info(f"{Fore.GREEN}Texto extraído e salvo em {json_output_path}")
            return json_output_path
        else:
            logging.warning(f"{Fore.YELLOW}Nenhuma transcrição encontrada para áudio {file_path}.")
            return None
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar áudio {file_path}: {e}")
        return None

# Função para processar arquivos de vídeo (extração de áudio e transcrição)
def process_video(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando vídeo {file_path}...")
        video = mp.VideoFileClip(file_path)
        audio_path = file_path.with_suffix('.mp3')
        video.audio.write_audiofile(audio_path, logger=None)
        
        return process_audio(audio_path)
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar vídeo {file_path}: {e}")
        return None

# Função para processar arquivos PDF
def process_pdf(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando PDF {file_path}...")
        with open(file_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            text = ""
            for page in reader.pages:
                text += page.extract_text() or ""
        
        if text:
            json_data = {
                "file_name": file_path.name,
                "file_type": "pdf",
                "content": text
            }

            json_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.json')
            json_output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(json_output_path, 'w', encoding='utf-8') as json_file:
                json.dump(json_data, json_file, ensure_ascii=False, indent=4)

            logging.info(f"{Fore.GREEN}Texto extraído e salvo em {json_output_path}")
            return json_output_path
        else:
            logging.warning(f"{Fore.YELLOW}Nenhum texto extraído do PDF {file_path}.")
            return None
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar PDF {file_path}: {e}")
        return None

# Função para processar arquivos DOCX
def process_docx(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando DOCX {file_path}...")
        doc = docx.Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])

        if text:
            json_data = {
                "file_name": file_path.name,
                "file_type": "docx",
                "content": text
            }

            json_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.json')
            json_output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(json_output_path, 'w', encoding='utf-8') as json_file:
                json.dump(json_data, json_file, ensure_ascii=False, indent=4)

            logging.info(f"{Fore.GREEN}Texto extraído e salvo em {json_output_path}")
            return json_output_path
        else:
            logging.warning(f"{Fore.YELLOW}Nenhum texto extraído do DOCX {file_path}.")
            return None
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar DOCX {file_path}: {e}")
        return None

# Função para processar arquivos de código
def process_code(file_path):
    try:
        logging.info(f"{Fore.CYAN}Processando código {file_path}...")
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()

        if code:
            json_data = {
                "file_name": file_path.name,
                "file_type": "code",
                "content": code
            }

            json_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.json')
            json_output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(json_output_path, 'w', encoding='utf-8') as json_file:
                json.dump(json_data, json_file, ensure_ascii=False, indent=4)

            logging.info(f"{Fore.GREEN}Código extraído e salvo em {json_output_path}")
            return json_output_path
        else:
            logging.warning(f"{Fore.YELLOW}Nenhum código extraído de {file_path}.")
            return None
    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar código {file_path}: {e}")
        return None

# Função para processar um único arquivo
def process_file(file):
    try:
        output_path = create_dir_structure(file, output_dir)
        processed_path = create_dir_structure(file, processed_dir)

        text_file = None
        if file.suffix.lower() in [
            '.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp', '.gif', 
            '.pbm', '.pgm', '.ppm'
        ]:
            text_file = process_image(file)

        elif file.suffix.lower() in ['.mp3', '.wav', '.flac']:
            text_file = process_audio(file)

        elif file.suffix.lower() in ['.mp4', '.avi', '.mov', '.mkv']:
            text_file = process_video(file)

        elif file.suffix.lower() == '.pdf':
            text_file = process_pdf(file)

        elif file.suffix.lower() == '.docx':
            text_file = process_docx(file)

        elif file.suffix.lower() in ['.py', '.java', '.cpp', '.js', '.html']:
            text_file = process_code(file)

        # Mover o arquivo original para a pasta de saída
        shutil.move(file, output_path)
        logging.info(f"{Fore.BLUE}Arquivo original movido para {output_path}")

        # Se o arquivo de texto foi gerado, mover para processed_dir
        if text_file:
            processed_json_path = processed_dir / text_file.relative_to(output_dir)
            processed_json_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(text_file, processed_json_path)
            logging.info(f"{Fore.GREEN}Arquivo JSON movido para {processed_json_path}")

    except Exception as e:
        logging.error(f"{Fore.RED}Erro ao processar o arquivo {file}: {e}")

# Função principal para processar todos os tipos de arquivos
def process_files():
    with ThreadPoolExecutor(max_workers=4) as executor:
        for subfolder in subfolders:
            subfolder_path = input_dir / subfolder
            if subfolder_path.exists():
                # Usando rglob para encontrar todos os arquivos em subpastas recursivamente
                for file in subfolder_path.rglob('*'):
                    if file.is_file():
                        executor.submit(process_file, file)

if __name__ == "__main__":
    process_files()
