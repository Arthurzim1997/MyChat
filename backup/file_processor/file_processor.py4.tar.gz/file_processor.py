import os
import docx
import PyPDF2
import moviepy.editor as mp
from pathlib import Path
import shutil
from concurrent.futures import ThreadPoolExecutor
import whisper
import pytesseract
from PIL import Image

# Caminho para a pasta do script (mesma pasta onde o script está localizado)
base_dir = Path(__file__).parent

# Diretórios relativos à pasta do script
input_dir = base_dir / "input_dir"
output_dir = base_dir / "output_dir"
processed_dir = base_dir / "processed_dir"  # Corrigido o nome para "processed_dir"

# Subpastas que devem existir dentro de 'input_dir'
subfolders = ['audio', 'code', 'images', 'text', 'video']

# Garantir que as pastas principais e as subpastas existam
for directory in [input_dir, output_dir, processed_dir]:
    if not directory.exists():
        print(f"Diretório {directory} não encontrado. Criando...")
        directory.mkdir(parents=True, exist_ok=True)

# Garantir que as subpastas dentro de 'input_dir', 'output_dir' e 'processed_dir' existam
for subfolder in subfolders:
    subfolder_input_path = input_dir / subfolder
    if not subfolder_input_path.exists():
        print(f"Subpasta {subfolder_input_path} não encontrada em 'input_dir'. Criando...")
        subfolder_input_path.mkdir(parents=True, exist_ok=True)
    
    subfolder_output_path = output_dir / subfolder
    if not subfolder_output_path.exists():
        print(f"Subpasta {subfolder_output_path} não encontrada em 'output_dir'. Criando...")
        subfolder_output_path.mkdir(parents=True, exist_ok=True)

    subfolder_processed_path = processed_dir / subfolder  # Alterado para "processed_dir"
    if not subfolder_processed_path.exists():
        print(f"Subpasta {subfolder_processed_path} não encontrada em 'processed_dir'. Criando...")
        subfolder_processed_path.mkdir(parents=True, exist_ok=True)

# Função para garantir que a estrutura de pastas seja criada
def create_dir_structure(file_path, base_dir):
    # Criar a estrutura de diretórios de forma limpa, relativa a input_dir
    new_dir = base_dir / file_path.relative_to(input_dir).parent  # Usando input_dir como base
    new_dir.mkdir(parents=True, exist_ok=True)
    return new_dir / file_path.name

# Função para processar arquivos de texto .docx
def process_docx(file_path):
    try:
        doc = docx.Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])
        return text
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos PDF
def process_pdf(file_path):
    try:
        with open(file_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            text = ""
            for page in range(len(reader.pages)):
                text += reader.pages[page].extract_text()
            return text
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos de áudio (transcrição para texto usando Whisper)
def process_audio(file_path):
    try:
        model = whisper.load_model("base")
        result = model.transcribe(file_path)
        return result["text"]
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos de vídeo (extração de áudio)
def process_video(file_path):
    try:
        video = mp.VideoFileClip(file_path)
        audio_path = file_path.with_suffix('.mp3')
        video.audio.write_audiofile(audio_path)
        return process_audio(audio_path)  # Processar o áudio extraído
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos de imagem (OCR com Tesseract)
def process_image(file_path):
    try:
        image = Image.open(file_path)
        return pytesseract.image_to_string(image)
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar arquivos de código
def process_code(file_path):
    try:
        with open(file_path, 'r') as f:
            code = f.read()
        return code
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return None

# Função para processar um único arquivo
def process_file(file):
    try:
        # Criar a estrutura de diretórios de saída, com base no diretório de input_dir
        processed_path = create_dir_structure(file, processed_dir)
        output_path = create_dir_structure(file, output_dir)

        # Processamento conforme o tipo de arquivo
        text = None
        if file.suffix == '.docx':
            text = process_docx(file)
        elif file.suffix == '.pdf':
            text = process_pdf(file)
        elif file.suffix in ['.mp3', '.wav']:
            text = process_audio(file)
        elif file.suffix == '.mp4':
            text = process_video(file)
        elif file.suffix in ['.py', '.js', '.java']:
            text = process_code(file)
        elif file.suffix in ['.jpg', '.jpeg', '.png']:
            text = process_image(file)

        # Salvar o texto processado, se houver
        if text:
            with open(processed_path, 'w') as f:
                f.write(text)

        # Mover o arquivo original para a pasta de saída (output_dir), não copiar
        shutil.move(file, output_path)  # Usando move para mover o arquivo original

    except Exception as e:
        print(f"Erro ao processar o arquivo {file}: {e}")

# Função principal para processar todos os tipos de arquivos
def process_files():
    # Criar diretórios de saída se não existirem
    for folder in [output_dir, processed_dir]:
        folder.mkdir(parents=True, exist_ok=True)

    # Processar arquivos em cada subpasta dentro de 'input_dir' com paralelismo
    with ThreadPoolExecutor(max_workers=4) as executor:
        for subfolder in subfolders:
            subfolder_path = input_dir / subfolder
            if subfolder_path.exists():
                for file in subfolder_path.iterdir():
                    if file.is_file():
                        executor.submit(process_file, file)

if __name__ == "__main__":
    process_files()
