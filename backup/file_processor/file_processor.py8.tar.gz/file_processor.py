import os
import docx
import PyPDF2
import moviepy.editor as mp
from pathlib import Path
import shutil
from concurrent.futures import ThreadPoolExecutor
import whisper
import pytesseract
from PIL import Image
from colorama import Fore, Style, init

# Inicializar colorama
init(autoreset=True)

# Caminho para a pasta do script (mesma pasta onde o script está localizado)
base_dir = Path(__file__).parent

# Diretórios relativos à pasta do script
input_dir = base_dir / "input_dir"
output_dir = base_dir / "output_dir"
processed_dir = base_dir / "processed_dir"

# Subpastas que devem existir dentro de 'input_dir'
subfolders = ['audio', 'code', 'images', 'text', 'video']

# Garantir que as pastas principais e as subpastas existam
for directory in [input_dir, output_dir, processed_dir]:
    if not directory.exists():
        print(f"{Fore.GREEN}Diretório {directory} não encontrado. Criando...")
        directory.mkdir(parents=True, exist_ok=True)

# Garantir que as subpastas dentro de 'input_dir', 'output_dir' e 'processed_dir' existam
for subfolder in subfolders:
    for base_path in [input_dir, output_dir, processed_dir]:
        subfolder_path = base_path / subfolder
        if not subfolder_path.exists():
            print(f"{Fore.GREEN}Subpasta {subfolder_path} não encontrada. Criando...")
            subfolder_path.mkdir(parents=True, exist_ok=True)

# Função para garantir que a estrutura de pastas seja criada
def create_dir_structure(file_path, base_dir):
    # Criar a estrutura de diretórios de forma limpa, relativa a input_dir
    new_dir = base_dir / file_path.relative_to(input_dir).parent
    new_dir.mkdir(parents=True, exist_ok=True)
    return new_dir / file_path.name

# Função para processar arquivos de imagem (OCR com Tesseract)
def process_image(file_path):
    try:
        print(f"{Fore.CYAN}Processando {file_path} com OCR (Tesseract)...")
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)

        if text:
            # Criar o arquivo de texto com a extensão .txt
            txt_file = file_path.with_suffix('.txt')  # Substituir a extensão para .txt
            txt_output_path = output_dir / file_path.relative_to(input_dir).with_suffix('.txt')

            # Garantir que a estrutura de saída exista
            txt_output_path.parent.mkdir(parents=True, exist_ok=True)

            # Salvar o texto extraído no arquivo .txt
            with open(txt_output_path, 'w', encoding='utf-8') as f:
                f.write(text)

            print(f"{Fore.GREEN}Texto extraído e salvo em {txt_output_path}")
            return txt_output_path
        else:
            print(f"{Fore.YELLOW}Nenhum texto extraído da imagem {file_path}.")
            return None
    except Exception as e:
        print(f"{Fore.RED}Erro ao processar {file_path}: {e}")
        return None

# Função para processar um único arquivo
def process_file(file):
    try:
        # Criar as estruturas de diretórios de saída
        output_path = create_dir_structure(file, output_dir)
        processed_path = create_dir_structure(file, processed_dir)

        # Processamento conforme o tipo de arquivo
        text_file = None
        if file.suffix.lower() in [
    '.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp', '.gif', 
    '.pbm', '.pgm', '.ppm'
]:
            text_file = process_image(file)

        # Mover o arquivo original para a pasta de saída
        shutil.move(file, output_path)
        print(f"{Fore.BLUE}Arquivo original movido para {output_path}")

        # Se o arquivo de texto foi gerado, mover para processed_dir
        if text_file:
            processed_txt_path = processed_dir / text_file.relative_to(output_dir)
            processed_txt_path.parent.mkdir(parents=True, exist_ok=True)  # Garantir estrutura
            shutil.move(text_file, processed_txt_path)
            print(f"{Fore.GREEN}Arquivo de texto movido para {processed_txt_path}")

    except Exception as e:
        print(f"{Fore.RED}Erro ao processar o arquivo {file}: {e}")

# Função principal para processar todos os tipos de arquivos
def process_files():
    with ThreadPoolExecutor(max_workers=4) as executor:
        for subfolder in subfolders:
            subfolder_path = input_dir / subfolder
            if subfolder_path.exists():
                for file in subfolder_path.iterdir():
                    if file.is_file():
                        executor.submit(process_file, file)

if __name__ == "__main__":
    process_files()
